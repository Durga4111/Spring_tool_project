package com.rays.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.rays.repository.StudentRepository;
import com.rays.service.Student;


@Service
public  class StudentDaoImp implements StudentDao  {
	
	@Autowired
	StudentRepository studentRepository ;

	
	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudent() {
		
		List<Student > studentList =  studentRepository.findAll();
		return studentList;
	}

	@Override
	public Student getStudentById(int id) {
		// TODO Auto-generated method stub
		Student student = studentRepository.getById(id);
		return  student;
	}

	
	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		studentRepository.save(student);

	}

	@Override
	public void deleteStudent(int Id) {
		// TODO Auto-generated method stub
		studentRepository.deleteById(Id);
	}

	@Override
	public Student  validateStudent(Student student) {
		// TODO Auto-generated method stub
		Student student1 = studentRepository.findByLoginData(student.getStudentName(), student.getStudentPassword());
		return student1;
	}

	
	}


